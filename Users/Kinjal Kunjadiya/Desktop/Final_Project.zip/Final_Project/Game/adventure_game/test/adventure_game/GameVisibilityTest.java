/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adventure_game;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Kinjal Kunjadiya
 */
public class GameVisibilityTest {
    
    public GameVisibilityTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of showGameTitleScreen method, of class GameVisibility.
     */
    @Test
    public void testShowGameTitleScreen() {
        System.out.println("showGameTitleScreen");
        GameVisibility instance = null;
        instance.showGameTitleScreen();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of gameTitleToDown method, of class GameVisibility.
     */
    @Test
    public void testGameTitleToDown() {
        System.out.println("gameTitleToDown");
        GameVisibility instance = null;
        instance.gameTitleToDown();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getUserName method, of class GameVisibility.
     */
    @Test
    public void testGetUserName() {
        System.out.println("getUserName");
        GameVisibility instance = null;
        instance.getUserName();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
