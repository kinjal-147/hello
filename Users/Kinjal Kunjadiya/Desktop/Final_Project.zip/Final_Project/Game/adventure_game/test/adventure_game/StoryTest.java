package adventure_game;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class StoryTest {
    
    public StoryTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of defaultSetup method, of class Story.
     */
    @Test
    public void testDefaultSetup() {
        System.out.println("defaultSetup");
        Story instance = null;
        instance.defaultSetup();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of selectPosition method, of class Story.
     */
    @Test
    public void testSelectPosition() {
        System.out.println("selectPosition");
        String nextPosition = "";
        Story instance = null;
        instance.selectPosition(nextPosition);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of mainBase method, of class Story.
     */
    @Test
    public void testMainBase() {
        System.out.println("mainBase");
        Story instance = null;
        instance.mainBase();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of searchFood method, of class Story.
     */
    @Test
    public void testSearchFood() {
        System.out.println("searchFood");
        Story instance = null;
        instance.searchFood();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of goJungle method, of class Story.
     */
    @Test
    public void testGoJungle() {
        System.out.println("goJungle");
        Story instance = null;
        instance.goJungle();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of pickKnife method, of class Story.
     */
    @Test
    public void testPickKnife() {
        System.out.println("pickKnife");
        Story instance = null;
        instance.pickKnife();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of towardsTree method, of class Story.
     */
    @Test
    public void testTowardsTree() {
        System.out.println("towardsTree");
        Story instance = null;
        instance.towardsTree();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of cutFruits method, of class Story.
     */
    @Test
    public void testCutFruits() {
        System.out.println("cutFruits");
        Story instance = null;
        instance.cutFruits();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of halfWinner method, of class Story.
     */
    @Test
    public void testHalfWinner() {
        System.out.println("halfWinner");
        Story instance = null;
        instance.halfWinner();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of magicalSword method, of class Story.
     */
    @Test
    public void testMagicalSword() {
        System.out.println("magicalSword");
        Story instance = null;
        instance.magicalSword();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of fightAnimal method, of class Story.
     */
    @Test
    public void testFightAnimal() {
        System.out.println("fightAnimal");
        Story instance = null;
        instance.fightAnimal();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of looser method, of class Story.
     */
    @Test
    public void testLooser() {
        System.out.println("looser");
        Story instance = null;
        instance.looser();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of waitHelp method, of class Story.
     */
    @Test
    public void testWaitHelp() {
        System.out.println("waitHelp");
        Story instance = null;
        instance.waitHelp();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of waitHelp2 method, of class Story.
     */
    @Test
    public void testWaitHelp2() {
        System.out.println("waitHelp2");
        Story instance = null;
        instance.waitHelp2();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of waitHelp3 method, of class Story.
     */
    @Test
    public void testWaitHelp3() {
        System.out.println("waitHelp3");
        Story instance = null;
        instance.waitHelp3();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of killAnimal method, of class Story.
     */
    @Test
    public void testKillAnimal() {
        System.out.println("killAnimal");
        Story instance = null;
        instance.killAnimal();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of attack method, of class Story.
     */
    @Test
    public void testAttack() {
        System.out.println("attack");
        Story instance = null;
        instance.attack();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of attack2 method, of class Story.
     */
    @Test
    public void testAttack2() {
        System.out.println("attack2");
        Story instance = null;
        instance.attack2();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of attack3 method, of class Story.
     */
    @Test
    public void testAttack3() {
        System.out.println("attack3");
        Story instance = null;
        instance.attack3();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of makePet method, of class Story.
     */
    @Test
    public void testMakePet() {
        System.out.println("makePet");
        Story instance = null;
        instance.makePet();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of prepareFood method, of class Story.
     */
    @Test
    public void testPrepareFood() {
        System.out.println("prepareFood");
        Story instance = null;
        instance.prepareFood();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of searchMaterial method, of class Story.
     */
    @Test
    public void testSearchMaterial() {
        System.out.println("searchMaterial");
        Story instance = null;
        instance.searchMaterial();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of hammer method, of class Story.
     */
    @Test
    public void testHammer() {
        System.out.println("hammer");
        Story instance = null;
        instance.hammer();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of findWoodern method, of class Story.
     */
    @Test
    public void testFindWoodern() {
        System.out.println("findWoodern");
        Story instance = null;
        instance.findWoodern();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of makeHammer method, of class Story.
     */
    @Test
    public void testMakeHammer() {
        System.out.println("makeHammer");
        Story instance = null;
        instance.makeHammer();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of cutter method, of class Story.
     */
    @Test
    public void testCutter() {
        System.out.println("cutter");
        Story instance = null;
        instance.cutter();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of findCutter method, of class Story.
     */
    @Test
    public void testFindCutter() {
        System.out.println("findCutter");
        Story instance = null;
        instance.findCutter();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of taskCutter method, of class Story.
     */
    @Test
    public void testTaskCutter() {
        System.out.println("taskCutter");
        Story instance = null;
        instance.taskCutter();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of taskCutter2 method, of class Story.
     */
    @Test
    public void testTaskCutter2() {
        System.out.println("taskCutter2");
        Story instance = null;
        instance.taskCutter2();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of taskCutter3 method, of class Story.
     */
    @Test
    public void testTaskCutter3() {
        System.out.println("taskCutter3");
        Story instance = null;
        instance.taskCutter3();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of taskCompleteCutter method, of class Story.
     */
    @Test
    public void testTaskCompleteCutter() {
        System.out.println("taskCompleteCutter");
        Story instance = null;
        instance.taskCompleteCutter();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of taskBackCutter method, of class Story.
     */
    @Test
    public void testTaskBackCutter() {
        System.out.println("taskBackCutter");
        Story instance = null;
        instance.taskBackCutter();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of makeBoat method, of class Story.
     */
    @Test
    public void testMakeBoat() {
        System.out.println("makeBoat");
        Story instance = null;
        instance.makeBoat();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of winner method, of class Story.
     */
    @Test
    public void testWinner() {
        System.out.println("winner");
        Story instance = null;
        instance.winner();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of lose method, of class Story.
     */
    @Test
    public void testLose() {
        System.out.println("lose");
        Story instance = null;
        instance.lose();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of end method, of class Story.
     */
    @Test
    public void testEnd() {
        System.out.println("end");
        Story instance = null;
        instance.end();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of toGameTitle method, of class Story.
     */
    @Test
    public void testToGameTitle() {
        System.out.println("toGameTitle");
        Story instance = null;
        instance.toGameTitle();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
