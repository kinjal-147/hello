//Final Assignment 
//Text-based Adventure Game using Swing
//Name : Kinjal Ghanshyambhai Kunjadiya
//Student Id : 2092926

package adventure_game;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class AdventureGame {

    OptionHandler oHandler = new OptionHandler();
    UI ui = new UI();
    GameVisibility gv = new GameVisibility(ui);
    Story story = new Story(this, ui, gv);
    String nextTaskPosition1, nextTaskPosition2, nextTaskPosition3;
    
    public static void main(String[] args) {
        new AdventureGame();
    }
    
    public AdventureGame(){
        ui.createUI(oHandler);
        story.defaultSetup();
        gv.showGameTitleScreen();
    }
    
    public class OptionHandler implements ActionListener {
        
         @Override
         public void actionPerformed(ActionEvent event){
            
            String yourOption = event.getActionCommand();
            
            switch(yourOption){
                
                case "start":
                    
                    if(ui.playerName.getText().equals("") || ui.playerSign.getText().equals("") || ui.playerGender.getText().equals("")) {
 
                        JFrame frame = new JFrame();
                        JOptionPane.showMessageDialog(frame,
                        "Enter your personal information..!", 
                        "warning",
                        JOptionPane.WARNING_MESSAGE);
                        gv.showGameTitleScreen();
                    }
                    else{  
                    
                        gv.gameTitleToDown(); 
                        story.mainBase();
                    }
                    break;
                    
                case "o1": story.selectPosition(nextTaskPosition1); break;                    
                case "o2": story.selectPosition(nextTaskPosition2); break;
                case "o3": story.selectPosition(nextTaskPosition3); break;
                    
            }
        }
    }

}














