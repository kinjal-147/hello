package adventure_game;

public class SuperMonster {
    
    public String name;
    public int hp;
    public int attack;
}
