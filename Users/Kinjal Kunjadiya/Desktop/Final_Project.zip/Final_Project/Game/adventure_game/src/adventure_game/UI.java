package adventure_game;

import adventure_game.AdventureGame.OptionHandler;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import javax.swing.JTextField;

/**
 *
 * @author Kinjal Kunjadiya
 */
public class UI{
    
    JFrame window;
    JPanel titleNamePanel, startButtonPanel, mainTextPanel, optionButtonPanel, playerPanel, uPanel, gPanel;
    JLabel titleNameLabel, hpLabel, hpNumberLabel, weaponLabel, weaponNumberLabel, pName, pSign;
    JButton startButton, option1, option2, option3, option4;
    JTextArea mainTextArea;
    int playerHP;
    String weapon, position;
    JTextField playerName, playerSign;
    JRadioButton playerGender;
    Font titleFont = new Font("Calibri", Font.PLAIN, 80);
    Font normalFont = new Font("Calibri", Font.PLAIN, 25);
    
    public void createUI(OptionHandler oHandler) {
        
        // Window
        window = new JFrame();
        window.setSize(850,700);
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.getContentPane().setBackground(Color.PINK);
        window.setLayout(null);
        
        // Title Screen
        titleNamePanel = new JPanel();
        titleNamePanel.setBounds(0, 100, 850, 250);
        titleNamePanel.setBackground(Color.PINK);
        titleNameLabel = new JLabel("Doremon Island");
        titleNameLabel.setForeground(Color.BLACK);
        titleNameLabel.setFont(titleFont);
        titleNamePanel.add(titleNameLabel);
        
        // Style the button panel
        startButtonPanel = new JPanel();
        startButtonPanel.setBounds(300,400,200,200);
        startButtonPanel.setBackground(Color.PINK);
        
        // Style the player's Name
        playerName=new JTextField("Enter Name",20);
        playerName.setBackground(Color.WHITE);
        startButtonPanel.add(playerName);
                 
        // Style the player's Sign
        playerSign=new JTextField("Enter Astrological Sign",20);
        playerSign.setBackground(Color.WHITE);
        startButtonPanel.add(playerSign);
                
        // Style the player's Gender
        playerGender=new JRadioButton("Male");
        playerGender.setBackground(Color.WHITE);
        startButtonPanel.add(playerGender);
        playerGender=new JRadioButton("Female");
        playerGender.setBackground(Color.WHITE);
        startButtonPanel.add(playerGender);
        
        startButton = new JButton("Play Game");
        startButton.setBackground(Color.BLACK);
        startButton.setForeground(Color.WHITE);
        startButton.setFont(normalFont);
        startButton.setFocusPainted(false);
        startButton.addActionListener(oHandler);
        startButton.setActionCommand("start");
        
        titleNamePanel.add(titleNameLabel);
        startButtonPanel.add(startButton);

        uPanel = new JPanel();
        uPanel.setBounds(0, 750, 850, 50);
        uPanel.setBackground(Color.PINK);
        uPanel.setLayout(new GridLayout(1,6));
        window.add(uPanel);
        pName = new JLabel("");
        pName.setFont(normalFont);
        pName.setForeground(Color.BLACK);
        uPanel.add(pName);
        pSign = new JLabel("");
        pSign.setFont(normalFont);
        pSign.setForeground(Color.BLACK);
        uPanel.add(pSign);
         
        window.add(titleNamePanel);
        window.add(startButtonPanel);

        // Game Screen
        mainTextPanel = new JPanel();
        mainTextPanel.setBounds(100,100,900,350);
        mainTextPanel.setBackground(Color.PINK);
        window.add(mainTextPanel);
        
        mainTextArea = new JTextArea();
        mainTextArea.setBounds(100,100,900,350);
        mainTextArea.setBackground(Color.PINK);
        mainTextArea.setForeground(Color.BLACK);
        mainTextArea.setFont(normalFont);
        mainTextArea.setLineWrap(true);
//        mainTextArea.setWrapStyleWord(true);
//        mainTextArea.setEditable(false);
        mainTextPanel.add(mainTextArea);
        
        optionButtonPanel = new JPanel();
        optionButtonPanel.setBounds(250,400,300,100);
        optionButtonPanel.setBackground(Color.PINK);
        optionButtonPanel.setLayout(new GridLayout(3,1));
        window.add(optionButtonPanel);
        
        // Option 1
        option1 = new JButton("Option 1");
        option1.setBackground(Color.BLACK);
        option1.setForeground(Color.WHITE);
        option1.setFont(normalFont);
        option1.setFocusPainted(false);
        option1.addActionListener(oHandler);
        option1.setActionCommand("o1");
        optionButtonPanel.add(option1);
                
        // Option 2
        option2 = new JButton("Option 2");
        option2.setBackground(Color.BLACK);
        option2.setForeground(Color.WHITE);
        option2.setFont(normalFont);
        option2.setFocusPainted(false);
        option2.addActionListener(oHandler);
        option2.setActionCommand("o2");
        optionButtonPanel.add(option2);
        
        // Option 3
        option3 = new JButton("Option 3");
        option3.setBackground(Color.BLACK);
        option3.setForeground(Color.WHITE);
        option3.setFont(normalFont);
        option3.setFocusPainted(false);
        option3.addActionListener(oHandler);
        option3.setActionCommand("o3");
        optionButtonPanel.add(option3);
             
        // Player Panel
        playerPanel = new JPanel();
        playerPanel.setBounds(1,20,900,50);
        playerPanel.setBackground(Color.BLACK);
        playerPanel.setLayout(new GridLayout(1,6));
        window.add(playerPanel);
                
        // Style the HP Panel
        hpLabel = new JLabel("HP :");
        hpLabel.setFont(normalFont);
        hpLabel.setForeground(Color.WHITE);
        playerPanel.add(hpLabel);
        
        hpNumberLabel = new JLabel();
        hpNumberLabel.setForeground(Color.RED);
        hpNumberLabel.setFont(normalFont);
        playerPanel.add(hpNumberLabel);
        
        // Style the Weapon Panel
        weaponLabel = new JLabel("Weapon:");
        weaponLabel.setForeground(Color.WHITE);
        weaponLabel.setFont(normalFont);
        playerPanel.add(weaponLabel);
        
        weaponNumberLabel = new JLabel("Knife");
        weaponNumberLabel.setForeground(Color.RED);
        weaponNumberLabel.setFont(normalFont);
        playerPanel.add(weaponNumberLabel);      
          
        window.setVisible(true);
    }

}
