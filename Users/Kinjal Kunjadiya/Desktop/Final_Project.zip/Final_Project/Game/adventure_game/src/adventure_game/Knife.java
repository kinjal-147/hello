package adventure_game;

public class Knife extends Weapon{
    
    public Knife() {
         
        weaponName = "Knife";
        damage = 7;
    }
    
}
