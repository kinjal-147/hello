package adventure_game;

public class MagicalSword extends Weapon {
    
    public MagicalSword() {
        weaponName = "Magical Sword";
        damage = 20;
        
    }
    
}
