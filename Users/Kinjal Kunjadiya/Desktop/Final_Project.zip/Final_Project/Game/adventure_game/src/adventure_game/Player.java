package adventure_game;

public class Player {
    
    public int hp;
    public Weapon currentWeapon;
    
}
