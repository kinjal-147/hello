package adventure_game;

public interface MainWeapon {
    
    public abstract void knife();
    public abstract void magicalSword();
}
