package adventure_game;

public class SuperWeapon {
    
    public String name;
    public int damage;
}
