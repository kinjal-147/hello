package adventure_game;

public class Weapon {
    
    public String weaponName;
    public int damage;

}
