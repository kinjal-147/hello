package adventure_game;

public class GameVisibility {
    
    UI ui;
    public GameVisibility(UI userInterface){
    
        ui = userInterface;
        
    }
    
    public void showGameTitleScreen(){
        
        // Show The Title Screen
        ui.titleNamePanel.setVisible(true);
        ui.startButtonPanel.setVisible(true);
        
        //Hide The Game Screen
        ui.mainTextPanel.setVisible(false);
        ui.optionButtonPanel.setVisible(false);
        ui.playerPanel.setVisible(false);
        
    }
    
    public void gameTitleToDown(){
        
        // Hide The Title Screen
        ui.titleNamePanel.setVisible(false);
        ui.startButtonPanel.setVisible(false);
        
        //Show The Game Screen
        ui.mainTextPanel.setVisible(true);
        ui.optionButtonPanel.setVisible(true);
        ui.playerPanel.setVisible(true);

    }

    void getUserName() {
        
        ui.pName.setText("Name : "+ui.playerName.getText());
	ui.pSign.setText("Sign : "+ui.playerSign.getText());    
    
    }
    
}
