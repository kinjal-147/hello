package adventure_game;

public class Story {
    
    AdventureGame game;
    UI ui;
    GameVisibility gv;
    Player player = new Player();
    int counter=0;
    String hpNumberLabel;
    String currentWeapon;

    /**
     *
     * @param g
     * @param userInterface
     * @param gVisibility
     */
    public Story(AdventureGame g, UI userInterface, GameVisibility gVisibility) {
        
        this.game = g;
        this.ui = userInterface;
        gv = gVisibility;
        
    }
    
    public void defaultSetup(){
        
        counter = 0;
        player.hp = 100;
        ui.hpNumberLabel.setText("" + player.hp);
        //ui.wName.setText("No Weapon");
        ui.pName.setText(ui.playerName.getText());
        player.currentWeapon = new Weapon();
        ui.weaponNumberLabel.setText(player.currentWeapon.weaponName);
        
    }
    
    public void selectPosition(String nextPosition) {
    
        switch(nextPosition) {
            
            case "mainBase": mainBase(); break;       
            case "goJungle": goJungle(); break;
            case "searchFood": searchFood(); break;
            case "pickKnife": pickKnife(); break;    
            case "towardsTree" : towardsTree(); break;
            case "cutFruits": cutFruits(); break;
            case "halfWinner": halfWinner(); break;            
            case "magicalSword": magicalSword(); break;
            case "fightAnimal": fightAnimal(); break;
            case "looser": looser(); break;            
            case "killAnimal": killAnimal(); break;
            case "attack": attack(); break;
            case "attack2": attack2(); break;
            case "attack3": attack3(); break;            
            case "makePet": makePet(); break;
            case "prepareFood": prepareFood(); break;            
            case "searchMaterial": searchMaterial(); break;
            case "hammer": hammer(); break;
            case "findWoodern": findWoodern(); break;
            case "makeHammer": makeHammer(); break;
            case "cutter": cutter(); break;
            case "findCutter": findCutter(); break;
            case "taskCutter": taskCutter(); break;
            case "taskCutter2": taskCutter2(); break;
            case "taskCutter3": taskCutter3(); break;
            case "taskCompleteCutter": taskCompleteCutter(); break;
            case "taskBackCutter": taskBackCutter(); break;
            case "makeBoat": makeBoat(); break;
            case "waitHelp": waitHelp(); break;
            case "waitHelp2": waitHelp2(); break;
            case "waitHelp3": waitHelp3(); break;            
            case "winner": winner(); break;
            case "lose": lose(); break;
            case "home": toGameTitle(); break;
            case "end": end(); break;
        }
        
    }
     
    public void mainBase(){
        
        counter = 1;
        player.hp = 100;
        ui.weaponNumberLabel.setText("No");
        ui.playerName.setText(ui.playerName.getText());
        
        ui.mainTextArea.setText("\nWelcome to the Doremon's Island..!! \n\nDoremon and his friends are stuck at Island \ndue to hole in boat.  \n\nNow, what will you do?");
        ui.option1.setText("Look for Food");
        ui.option2.setText("Search for Material");
        ui.option3.setText("Wait for Help");
        
        game.nextTaskPosition1 = "searchFood";
        game.nextTaskPosition2 = "searchMaterial";
        game.nextTaskPosition3 = "waitHelp";    
         
    }
    
    public void searchFood() {
        
        counter+=1;
        ui.mainTextArea.setText("\n You have two options, \n Choose Wisely..!");
        player.hp = player.hp +10;
        ui.hpNumberLabel.setText("" + player.hp);
        ui.option1.setText("Go to jungle");
        ui.option2.setText("Kill animal");
        ui.option3.setText("Leave");
        
        game.nextTaskPosition1 = "goJungle";
        game.nextTaskPosition2 = "killAnimal";
        game.nextTaskPosition3 = "home";
    }
    
    public void goJungle() {
        
        counter+=1;
        ui.mainTextArea.setText("\nYou are entered in a jungle.! \nYou have to choose one weapon.!");
        ui.option1.setText("Pick up knife");
        ui.option2.setText("Magical sword");
        ui.option3.setText("Go Back");
               
        game.nextTaskPosition1 = "pickKnife";
        game.nextTaskPosition2 = "magicalSword";
        game.nextTaskPosition3 = "searchFood";
    }
    
    public void pickKnife() {
        
        counter+=1;
        player.hp = player.hp -10;
        player.currentWeapon = new Knife();
        ui.weaponNumberLabel.setText(player.currentWeapon.weaponName);
	player.hp=100+new java.util.Random().nextInt(20);
        ui.hpNumberLabel.setText("" +player.hp);

		
        ui.mainTextArea.setText("\nNow, You have a " +player.currentWeapon.weaponName+ " as a weapon.!");
        ui.option1.setText("Towards tree");
        ui.option2.setText("Go Back");
        ui.option3.setText("Leave");
               
        game.nextTaskPosition1 = "towardsTree";
        game.nextTaskPosition2 = "goJungle";
        game.nextTaskPosition3 = "home";
    }
    
    public void towardsTree() {
        
        counter+=1;
        player.currentWeapon = new Knife();
        ui.weaponNumberLabel.setText(player.currentWeapon.weaponName);
	player.hp=100+new java.util.Random().nextInt(2000);

        ui.mainTextArea.setText("\nYou are near to the trees to cut the fruits!");
        ui.option1.setText("Cut Fruits");
        ui.option2.setText("Go Back");
        ui.option3.setText("Leave");
               
        game.nextTaskPosition1 = "cutFruits";
        game.nextTaskPosition2 = "pickKnife";
        game.nextTaskPosition3 = "home";
    }
    
    public void cutFruits() {
        
        counter+=1;
        ui.mainTextArea.setText("\n Now, you have to make food.!");
        ui.option1.setText("Make food");
        ui.option2.setText("Go Back");
        ui.option3.setText("Leave");
               
        game.nextTaskPosition1 = "halfWinner";
        game.nextTaskPosition2 = "towardsTree";
        game.nextTaskPosition3 = "home";
    }
    
    public void halfWinner() {
        
        counter+=1;
        ui.mainTextArea.setText("\nHurray....!! \nYou have your food, \nNow, you have to find the material to repair the boat.!");
        ui.option1.setText("Look For Material");
        ui.option2.setText("Go Back");
        ui.option3.setText("Leave");
               
        game.nextTaskPosition1 = "searchMaterial";
        game.nextTaskPosition2 = "cutFruits";
        game.nextTaskPosition3 = "home";
    }
    
    public void magicalSword() {
        
        counter+=1;
        player.hp = player.hp -10;
        player.currentWeapon = new MagicalSword();
        ui.weaponNumberLabel.setText(player.currentWeapon.weaponName);
	player.hp=100+new java.util.Random().nextInt(20);
        ui.hpNumberLabel.setText("" +player.hp);
      
        ui.mainTextArea.setText("\nYou have a " +player.currentWeapon.weaponName+ " as a weapon. \nYou have to fight with an animal.!");
        ui.option1.setText("Fight with Animal");
        ui.option2.setText("Go Back");
        ui.option3.setText("Leave");
               
        game.nextTaskPosition1 = "fightAnimal";
        game.nextTaskPosition2 = "mainBase";
        game.nextTaskPosition3 = "home";
    }
    
    public void fightAnimal() {
        
        counter+=1;
        player.hp = player.hp -10;
        ui.hpNumberLabel.setText("" + player.hp);  
        ui.mainTextArea.setText("\nYou have to fight again.!");
        ui.option1.setText("Fight again");
        ui.option2.setText("Go Back");
        ui.option3.setText("Leave");
               
        game.nextTaskPosition1 = "looser";
        game.nextTaskPosition2 = "mainBase";
        game.nextTaskPosition3 = "home";
    }
    
    public void looser() {
        
        counter+=1;
        ui.mainTextArea.setText("\nYou lose the Game.!");
        ui.option1.setText("Exit");
        ui.option2.setText("");
        ui.option3.setText("");
               
        game.nextTaskPosition1 = "end";
        game.nextTaskPosition2 = "";
        game.nextTaskPosition3 = "";
    }
    
    public void waitHelp(){
        
        counter += 1;
        ui.mainTextArea.setText("\nYou have to wait..!!");
        player.hp = player.hp -20;
        ui.hpNumberLabel.setText("" + player.hp);
        ui.option1.setText("\nWait for Help.!");
        ui.option2.setText("Go Back");
        ui.option3.setText("Leave");
        
        game.nextTaskPosition1 = "waitHelp2";
        game.nextTaskPosition2 = "mainBase";
        game.nextTaskPosition3 = "home";    
         
    }
    
    public void waitHelp2(){
        
        counter += 1;
        ui.mainTextArea.setText("\nYou have to wait more..!!");
        player.hp = player.hp -40;
        ui.hpNumberLabel.setText("" + player.hp);
        ui.option1.setText("Waiting more");
        ui.option2.setText("Go Back");
        ui.option3.setText("Leave");
        
        game.nextTaskPosition1 = "waitHelp3";
        game.nextTaskPosition2 = "mainBase";
        game.nextTaskPosition3 = "home";    
         
    }
    
    public void waitHelp3(){
        
        counter += 1;
        ui.mainTextArea.setText("\nNo-one has come, \nYou lose the game..!!");
        player.hp = player.hp -60;
        ui.hpNumberLabel.setText("" + player.hp);
        ui.option1.setText("Exit");
        ui.option2.setText("");
        ui.option3.setText("");
        ui.option2.setVisible(false);
        ui.option3.setVisible(false);
        
        game.nextTaskPosition1 = "end";
        game.nextTaskPosition2 = "";
        game.nextTaskPosition3 = "";    
         
    }
    
    public void killAnimal() {
        
        counter += 1;
        ui.mainTextArea.setText("\nYou have two option, \nChoose one wisely.!");
        player.hp = player.hp +10;
        ui.hpNumberLabel.setText("" + player.hp);
        ui.option1.setText("Attack");
        ui.option2.setText("Making pet");
        ui.option3.setText("Go Back");
        
        game.nextTaskPosition1 = "attack";
        game.nextTaskPosition2 = "makePet";
        game.nextTaskPosition3 = "mainBase";
    }
    
    public void attack() {
        
        counter += 1;
        ui.mainTextArea.setText("\nYou have to attack on animal.!");
        player.hp = player.hp -10;
        ui.hpNumberLabel.setText("" + player.hp);
        ui.option1.setText("Attack again");
        ui.option2.setText("Go Back");
        ui.option3.setText("Leave");
        
        game.nextTaskPosition1 = "attack2";
        game.nextTaskPosition2 = "killAnimal";
        game.nextTaskPosition3 = "home";
    }
    
    public void attack2() {
        
        counter += 1;
        ui.mainTextArea.setText("\nYou have to attach again.!");
        player.hp = player.hp -20;
        ui.hpNumberLabel.setText("" + player.hp);
        ui.option1.setText("Attack again");
        ui.option2.setText("Go Back");
        ui.option3.setText("Leave");
        
        game.nextTaskPosition1 = "attack3";
        game.nextTaskPosition2 = "attack2";
        game.nextTaskPosition3 = "home";
    }
    
    public void attack3() {
        
        counter += 1;
        ui.mainTextArea.setText("\nI am sorry but, \nYou lost the game.!");
        player.hp = player.hp -20;
        ui.hpNumberLabel.setText("" + player.hp);
        ui.option1.setText("Exit");
        ui.option2.setText("");
        ui.option3.setText("");
        ui.option2.setVisible(false);
        ui.option3.setVisible(false);
        
        game.nextTaskPosition1 = "end";
        game.nextTaskPosition2 = "";
        game.nextTaskPosition3 = "";
    }
    
    public void makePet() {
        
        counter += 1;
        ui.mainTextArea.setText("\nHurray..!! \nYou make an animal to a pet.!");
        player.hp = player.hp +20;
        ui.hpNumberLabel.setText("" + player.hp);
        ui.option1.setText("Kill the animal");
        ui.option2.setText("Go Back");
        ui.option3.setText("Leave");
        
        game.nextTaskPosition1 = "prepareFood";
        game.nextTaskPosition2 = "killAnimal";
        game.nextTaskPosition3 = "home";
    }
    
    public void prepareFood() {
        
        counter += 1;
        ui.mainTextArea.setText("\nYou have to prepare the food of the dead animal.!");
        player.hp = player.hp +5;
        ui.hpNumberLabel.setText("" + player.hp);
        ui.option1.setText("Make Food");
        ui.option2.setText("Go Back");
        ui.option3.setText("Leave");
        
        game.nextTaskPosition1 = "halfWinner";
        game.nextTaskPosition2 = "makePet";
        game.nextTaskPosition3 = "home";
    }
    
    public void searchMaterial() {
        
        counter += 1;
        ui.mainTextArea.setText("\nDoremon: Hello Stranger, \nPlease help me to reach my place.");
        player.hp = player.hp +10;
        ui.hpNumberLabel.setText("" + player.hp);
        ui.option1.setText("Make hammer");
        ui.option2.setText("Woodern cutter");
        ui.option3.setText("Go Back");
        
        game.nextTaskPosition1 = "hammer";
        game.nextTaskPosition2 = "cutter";
        game.nextTaskPosition3 = "mainBase";

    }
    
    public void hammer() {
        
        counter += 1;
        ui.mainTextArea.setText("\nFind wood to make hammer.!");
        player.hp = player.hp +5;
        ui.hpNumberLabel.setText("" + player.hp);
        ui.option1.setText("Find Woodern");
        ui.option2.setText("Go Back");
        ui.option3.setText("Leave");

        game.nextTaskPosition1 = "findWoodern";
        game.nextTaskPosition2 = "searchMaterial";
        game.nextTaskPosition3 = "home";
        
    }
    
    public void findWoodern() {
        
        counter += 1;
        ui.mainTextArea.setText("\nCongratulations, \nYou have find the hammer,  \nNow you have to cut the wood.!");
        player.hp = player.hp +5;
        ui.hpNumberLabel.setText("" + player.hp);
        ui.option1.setText("Cut Wood");
        ui.option2.setText("Go Back");
        ui.option3.setText("Leave");

        game.nextTaskPosition1 = "makeHammer";
        game.nextTaskPosition2 = "hammer";
        game.nextTaskPosition3 = "home";
        
    }
    
    public void makeHammer() {
        
        counter += 1;
        ui.mainTextArea.setText("\nCongratulations, \nYou have to make the hammer.!");
        player.hp = player.hp +5;
        ui.hpNumberLabel.setText("" + player.hp);
        ui.option1.setText("Find Woodern Cutter");
        ui.option2.setText("Go Back");
        ui.option3.setText("Leave");

        game.nextTaskPosition1 = "cutter";
        game.nextTaskPosition2 = "findWoodern";
        game.nextTaskPosition3 = "home";
        
    }
    
    public void cutter() {
        
        counter += 1;
        ui.mainTextArea.setText("\nYou have to find the cutter for \nRepairing to boat..!");
        player.hp = player.hp +10;
        ui.hpNumberLabel.setText("" + player.hp);  
        ui.option1.setText("Find Cutter");
        ui.option2.setText("Go Back");
        ui.option3.setText("Leave");

        game.nextTaskPosition1 = "findCutter";
        game.nextTaskPosition2 = "makeHammer";
        game.nextTaskPosition3 = "home";
        
    }
    
    public void findCutter() {
        
        counter += 1;
        ui.mainTextArea.setText("\nTheir is one guy, who have a woodern cutter \nIf you want it then \nYou have to complete the task.!");
        player.hp = player.hp +10;
        ui.hpNumberLabel.setText("" + player.hp);  
        ui.option1.setText("Start Task1");
        ui.option2.setText("Start Task2");
        ui.option3.setText("Go Back");

        game.nextTaskPosition1 = "taskCutter";
        game.nextTaskPosition2 = "taskCutter2";
        game.nextTaskPosition3 = "cutter";
        
    }
    
    public void taskCutter() {
        
        counter += 1;
        ui.mainTextArea.setText("\nYou have to do fishing for the woodern cutter.!");
        player.hp = player.hp +5;
        ui.hpNumberLabel.setText("" + player.hp);  
        ui.option1.setText("Fishing");
        ui.option2.setText("Go Back");
        ui.option3.setText("Leave");

        game.nextTaskPosition1 = "taskCompleteCutter";
        game.nextTaskPosition2 = "findCutter";
        game.nextTaskPosition3 = "home";
        
    }
    
    public void taskCutter2() {
        
        counter += 1;
        ui.mainTextArea.setText("\nYou have to fight with the person for the woodern cutter.!");
        player.hp = player.hp -10;
        ui.hpNumberLabel.setText("" + player.hp);  
        ui.option1.setText("Fight");
        ui.option2.setText("Go Back");
        ui.option3.setText("Leave");

        game.nextTaskPosition1 = "taskCutter3";
        game.nextTaskPosition2 = "findCutter";
        game.nextTaskPosition3 = "home";
        
    }
    
    public void taskCutter3() {
        
        counter += 1;
        ui.mainTextArea.setText("\nYou have to fight again!");
        player.hp = player.hp -30;
        ui.hpNumberLabel.setText("" + player.hp);  
        ui.option1.setText("Fight again");
        ui.option2.setText("Go Back");
        ui.option3.setText("Leave");

        game.nextTaskPosition1 = "looser";
        game.nextTaskPosition2 = "findCutter";
        game.nextTaskPosition3 = "home";
        
    }
    
    public void taskCompleteCutter() {
        
        counter += 1;
        ui.mainTextArea.setText("\nYou are doing fishing for the woodern cutter.!");
        player.hp = player.hp +10;
        ui.hpNumberLabel.setText("" + player.hp);  
        ui.option1.setText("Done Fishing");
        ui.option2.setText("Go Back");
        ui.option3.setText("Leave");

        game.nextTaskPosition1 = "taskBackCutter";
        game.nextTaskPosition2 = "taskCutter";
        game.nextTaskPosition3 = "home";
        
    }
    
    public void taskBackCutter() {
        
        counter += 1;
        ui.mainTextArea.setText("\nYou have done the fishing \nNow you get the woodern cutter.!");
        player.hp = player.hp +10;
        ui.hpNumberLabel.setText("" + player.hp);  
        ui.option1.setText("Make Boat");
        ui.option2.setText("Go Back");
        ui.option3.setText("Leave");

        game.nextTaskPosition1 = "makeBoat";
        game.nextTaskPosition2 = "taskCompleteCutter";
        game.nextTaskPosition3 = "home";
        
    }
    
    public void makeBoat() {
        
        counter += 1;
        ui.mainTextArea.setText("\nCongratulations, \nYou have make the boat..!");
        player.hp = player.hp +10;
        ui.hpNumberLabel.setText("" + player.hp);  
        ui.option1.setText("Exit");
        ui.option2.setText("");
        ui.option3.setText("");
        ui.option2.setVisible(false);
        ui.option3.setVisible(false);

        game.nextTaskPosition1 = "end";
        game.nextTaskPosition2 = "";
        game.nextTaskPosition3 = "";
        
    }
        
    public void winner() {
           
        ui.option1.setText("Making Pet");
        ui.option2.setText("");
        ui.option3.setText("");
    
        game.nextTaskPosition1 = "mainBase";
        game.nextTaskPosition2 = "";
        game.nextTaskPosition3 = "";
                
    }
    
    public void lose() {
        
        ui.mainTextArea.setText("\nYou have dead..! \n\n <GAME OVER>");
    
        ui.option1.setText("To the title screen");
        ui.option2.setText("");
        ui.option3.setText("");
    
        game.nextTaskPosition1 = "toTitle";
        game.nextTaskPosition2 = "";
        game.nextTaskPosition3 = "";
                
    }
    
    public void end() {
        
        ui.mainTextArea.setText("\nTHE END!!!! \nPlayer's name: "+ui.playerName.getText() +"\nPlayer's Astrological sign : "+ui.playerSign.getText()+"\nChoices selected in journey :" +counter);
       
        ui.option1.setText("Play Again.");
        ui.option2.setText("");
        ui.option3.setText("");
        ui.option2.setVisible(false);
        ui.option3.setVisible(false);
        
        game.nextTaskPosition1="home";
        game.nextTaskPosition2="";
        game.nextTaskPosition3="";
		
    }
     
    public void toGameTitle() {
        defaultSetup();
        gv.showGameTitleScreen();
    }

}
